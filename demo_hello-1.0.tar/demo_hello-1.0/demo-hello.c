#include<stdio.h>

int main(int argc,char *argv[])
{
	
   printf("hello!\r\n");
   return 0;   
	
}

